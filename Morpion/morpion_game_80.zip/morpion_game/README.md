<?php

// Initialisation
list ($x, $y) = explode(readline());
// Boucle
while (condition) {
    list ($x, $y) = explode(readline());
}
-----------------------------------------------------------
do {


} while ();