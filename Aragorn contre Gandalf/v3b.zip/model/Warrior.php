<?php
/*
 * Référentiel de la classe Warrior
 * Conventions de code : PascalCase
 * extends = hérite des propriétés publics/protégées (UN SEUL HERITAGE POSSIBLE)
 * final = non héritable (non obligatoire)
 */
include_once('model/Character.php');
final class Warrior extends Character
{
    /**
     * Constructeur de la classe Warrior
     * On attend un paramètre correspondant au nom
     * > Valeur facultative. Si pas présent, valeur par défaut : Guerrier
     */
    public function __construct(string $sName = 'Guerrier')
    {
        $this->name = $sName;
    }
}