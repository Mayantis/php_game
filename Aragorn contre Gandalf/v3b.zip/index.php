<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);

include_once('model/Character.php');
include_once('model/Wizard.php');
include_once('model/Warrior.php');

/**
 * Simule un combat entre $a et $b
 * A frappe B avec une force XX >> B perds XX points de vie
 * @param Character $a
 * @param Character $b
 */
function hit (Character $a, Character $b) : void
{
    //> Récupérer la force de $a > le stocker dans $strengthA
    $strengthA = $a->getStrength();

    //> Récupérer la santé de $b > le stocker dans $healthB
    $healthB = $b -> getHealth();

    // Calcul de l'attaque
    $newHealthB = $healthB - $strengthA;
    
    // Exécution de l'attaque
    $b -> setHealth ( $newHealthB ) ;
}

/*$aAragorn = [
    'name' => 'Aragorn',
    'health' => 50,
    'strength' => 100,
];
display($aAragorn);

function display(array $aCharacter)
{
    print_r($aCharacter);
}*/

// new = Appel de la fonction __construct
$oAragorn = new Warrior('Aragorn');
$oAragorn->setHealth(150);
$oAragorn->setStrength(50);
// echo = appel de la fonction __toString
echo $oAragorn . PHP_EOL;

$oGandalf = new Wizard('Gandalf');
$oGandalf->setHealth(70);
$oGandalf->setStrength(20);
$oGandalf->setMagic(200);
// appel de la fonction personnalisée "display"
$oGandalf->display();

/*
Exercice 1
> Créer un Guerrier "Aragorn" [Santé : 150 ; Force : 50]
> Créer un Magicien "Gandalf" [Santé : 70 ; Force : 20 ; Mana : 200]
> Afficher les personnages en mode "debug"

> Créer une fonction (hit) pour simuler le combat entre deux personnages A et B
> ex: A frappe B avec une force XX >> B perds XX points de vie
*/ 
echo '-------- PHASE DE COMBAT --------'.PHP_EOL;
$oAragorn->display();
$oGandalf->display();

// Version procédurale
// hit ($oAragorn, $oGandalf);

// Version orienté-objet
$oAragorn -> hit ($oGandalf);

$oGandalf->fireball ($oAragorn);
$oGandalf->heal ();

$oAragorn->display();
$oGandalf->display();

// Possible car FIREBALL_DAMAGE est publique
echo '[INFO] FIREBALL_DAMAGE = ' . Wizard::FIREBALL_DAMAGE . PHP_EOL;

// Pas possible car HEAL_DAMAGE est privée
//echo '[INFO] HEAL_DAMAGE = ' . Wizard::HEAL_DAMAGE . PHP_EOL;