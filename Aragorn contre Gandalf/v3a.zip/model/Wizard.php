<?php
/*
 * Référentiel de la classe Wizard
 * Conventions de code : PascalCase
 * extends = hérite des propriétés publics/protégées
 * final = non héritable (non obligatoire)
 */
include_once('model/Character.php');
final class Wizard extends Character
{
    /*
     * Propriétés/Attributs
     * Conventions de code : camelCase
     */
    private $magic;

    /**
     * Get the value of magic
     */ 
    public function getMagic()
    {
        return $this->magic;
    }

    /**
     * Set the value of magic
     *
     * @return  self
     */ 
    public function setMagic($magic)
    {
        $this->magic = $magic;

        return $this;
    }
}