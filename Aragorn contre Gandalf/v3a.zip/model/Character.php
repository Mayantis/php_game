<?php
/*
 * Référentiel de la classe Character
 * Conventions de code : PascalCase
 * abstract = non instanciable (non obligatoire)
 */
abstract class Character 
{
    /*
     * Propriétés/Attributs
     * Conventions de code : camelCase
     * protected = propriétés héritables
     */
    protected $name;
    protected $health;
    protected $strength;

    /**
     * Constructeur de la classe Character
     * On attend un paramètre correspondant au nom
     * > Valeur obligatoire
     */
    public function __construct(string $sName)
    {
        $this->name = $sName;
    }

    /**
     * Simule un combat entre deux joueurs A et B
     * A frappe B avec une force XX >> B perds XX points de vie
     * @param Character $b
     * 
     * $this = instance appelante (ici l'attaquant "A")
     * $b = instance en paramètre (ici l'attaqué "B")
    */
    function hit (Character $b) : void
    {
        $b -> setHealth ( $b->getHealth() - $this->getStrength() ) ;
    }

    /**
     * Fonction spéciale permettant de convertir votre objet en chaîne de caractère (via echo par exemple)
     */
    public function __toString()
    {
        return $this->name;
    }

    public function display()
    {
        print_r($this);
    }
    
    /**
     * Get /*
     */ 
    public function getName()
    {
        return $this->name;
    }

    /**
     * Set /*
     *
     * @return  self
     */ 
    public function setName($name)
    {
        $this->name = $name;

        return $this;
    }

    /**
     * Get the value of health
     */ 
    public function getHealth()
    {
        return $this->health;
    }

    /**
     * Set the value of health
     *
     * @return  self
     */ 
    public function setHealth($health)
    {
        $this->health = $health;

        return $this;
    }

    /**
     * Get the value of strength
     */ 
    public function getStrength()
    {
        return $this->strength;
    }

    /**
     * Set the value of strength
     *
     * @return  self
     */ 
    public function setStrength($strength)
    {
        $this->strength = $strength;

        return $this;
    }
}